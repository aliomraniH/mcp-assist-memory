# Debug brief: canvas-growth-charts percentile bands

11 checks passed, 2 failed. Percentile bands fail to render when age == 0:
`PercentileLayer.render` receives `bands === undefined` because
`/api/percentiles?age=0` returns 404.

Suggested fix order:
1. Add the age=0 row to the percentiles fixture/API.
2. Guard `PercentileLayer.render` against missing bands.

Rerun: `npx debug-capture --rerun 2026-06-09T14-30-00Z_canvas-debug`
